import argparse
import pandas
import os.path as osp
import warnings
import json


def count_words_for_all_ponies(df):
    ponies_json = {
        'twilight sparkle': 0,
        'applejack': 0,
        'rainbow dash': 0,
        'rarity': 0,
        'pinkie pie': 0,
        'fluttershy': 0
    }
    dfg = df.groupby(['pony'])
    for group, pony_speeches in dfg:
        words_for_a_pony = {}
        if ponies_json.keys().__contains__(pony_speeches.iloc[0, 0]):
            # print(pony_speeches)
            for sentence in pony_speeches['dialog']:
                words = sentence.split(' ')
                while '' in words:
                    words.remove('')
                for word in words:
                    if word.isalpha():
                        if word not in words_for_a_pony.keys():
                            words_for_a_pony.update({word: 1})
                        else:
                            words_for_a_pony.update({word: int(words_for_a_pony.get(word))+1})
            words_for_a_pony = {k: v for k, v in words_for_a_pony.items() if v >= 5}
            words_for_a_pony = \
                {k: v for k, v in sorted(words_for_a_pony.items(), key=lambda item: item[1], reverse=True)}
            # print(words_for_a_pony)
                #print(words)
            ponies_json.update({pony_speeches.iloc[0, 0]: words_for_a_pony})
    return ponies_json


def clean_dialog_and_return_data_frame(dialog_file):
    with open(dialog_file, 'r') as dialog:
        df = pandas.read_csv(dialog)
        df = df[['pony', 'dialog']]
        df['dialog'] = df['dialog'].str.replace('<U+.*>', ' ', regex=True)\
            .replace('[()\[\],-.?!;:#&]', ' ', regex=True)
        for i in range(0, len(df['pony'])):
            df.iloc[i, 0] = df.iloc[i, 0].lower()
            df.iloc[i, 1] = str(df.iloc[i, 1]).lower()

    return df


def main():
    warnings.filterwarnings('ignore')
    parser = argparse.ArgumentParser()
    parser.add_argument('-o', '--word_counts_json', help='The json output file containing word counts of ponies')
    parser.add_argument('dialog_file')
    args = parser.parse_args()

    dialog_file = args.dialog_file
    word_counts_json = args.word_counts_json

    if word_counts_json is None:
        print("Error. A output file should be provided!")
        exit(0)

    if not osp.isabs(dialog_file):
        dialog_file = osp.abspath(dialog_file)

    # print(dialog_file, word_counts_json)

    df = clean_dialog_and_return_data_frame(dialog_file)
    # print(df)'

    ponies_json = count_words_for_all_ponies(df)
    # print(ponies_json)
    with open(word_counts_json, 'w') as outfile:
        json.dump(ponies_json, outfile, indent=4)


if __name__ == '__main__':
    main()
