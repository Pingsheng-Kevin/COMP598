import argparse
import json
import os.path as osp
import math


def calculate_tf_idf_from_json(pony_counts_json, num_words, mode):
    ponies_words_tf_idf = {}
    words_df = {}
    with open(pony_counts_json, 'r') as pony_counts_json:
        ponies_words_json = json.load(pony_counts_json)
        for pony, words in ponies_words_json.items():
            for word in words.keys():
                if word not in words_df.keys():
                    words_df.update({word: words.get(word)})
                else:
                    words_df.update({word: int(words_df.get(word) + words.get(word))})
        # print(words_df)
        total_num_of_words = sum(words_df.values())
        for pony, words in ponies_words_json.items():
            words_tf_idf = {}
            # all_words_of_a_pony = sum(words.values())
            # print(words.values())
            # words_tf_idf.update({pony: []})
            for word in words.keys():
                if not mode:
                    tf_idf = words.get(word) * math.log(float(total_num_of_words/words_df.get(word)), 10)
                else:
                    total_mention_of_word_among_ponies = \
                        sum([1 for pony in ponies_words_json.keys() if word in ponies_words_json.get(pony).keys()])
                    num_of_pony = len(ponies_words_json.keys())
                    tf_idf = words.get(word) * math.log(float(num_of_pony)/total_mention_of_word_among_ponies, 10)

                words_tf_idf.update({word: tf_idf})
                words_tf_idf = {k: v for k, v in sorted(words_tf_idf.items(), key=lambda item: item[1], reverse=True)}
            ponies_words_tf_idf.update({pony: [k for k in list(words_tf_idf.keys())[:num_words]]})
            # for word in words.keys():
        # print(ponies_words_tf_idf)
        return ponies_words_tf_idf


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-p', action='store_true')
    parser.add_argument('pony_counts_json')
    parser.add_argument('num_words')
    args = parser.parse_args()

    mode = args.p
    pony_counts_json = args.pony_counts_json
    num_words = int(args.num_words)

    if not osp.isabs(pony_counts_json):
        pony_counts_json = osp.abspath(pony_counts_json)

    ponies_words_tf_idf = calculate_tf_idf_from_json(pony_counts_json, num_words, mode)

    print(json.dumps(ponies_words_tf_idf, indent=4))


if __name__ == '__main__':
    main()
