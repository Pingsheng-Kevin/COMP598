import unittest
import os.path as osp
from hw3.check_list_length import Check_L
from hw3.generate_dic import Gen_Dic
from hw3.generate_words_dic import Generate_Words_Dic

class TestCases(unittest.TestCase):

    def test_Length6(self):

        self.assertEqual(Check_L.list_length([1, 2, 3, 4, 5, 6]), True)

    def test_Length0(self):

        self.assertEqual(Check_L.list_length([]), False)

    def test_Length1(self):

        self.assertEqual(Check_L.list_length([1]), False)

    def test_Dic(self):

        self.assertEqual(Gen_Dic.gen_dic(
            osp.join(osp.dirname(osp.dirname(osp.dirname(osp.dirname(osp.abspath(__file__))))),
                     'data', 'words_alpha.txt')
        ).__contains__('i'), True)

    def test_Dic_Cap(self):
        self.assertEqual(Gen_Dic.gen_dic(
            osp.join(osp.dirname(osp.dirname(osp.dirname(osp.dirname(osp.abspath(__file__))))),
                     'data', 'words_alpha.txt')
        ).__contains__('I'), False)

    def test_Dic_NonAN(self):
        self.assertEqual(Gen_Dic.gen_dic(
            osp.join(osp.dirname(osp.dirname(osp.dirname(osp.dirname(osp.abspath(__file__))))),
                     'data', 'words_alpha.txt')
        ).__contains__(r'[^a-zA-Z0-9]'), False)

    def test_Dic_Abb(self):
        self.assertEqual(Gen_Dic.gen_dic(
            osp.join(osp.dirname(osp.dirname(osp.dirname(osp.dirname(osp.realpath(__file__))))),
                     'data', 'words_alpha.txt')
        ).__contains__('i\'ve'), False)

    def test_words_dic(self):
        self.assertEqual(Generate_Words_Dic.gen_words_dic(
            {'hello': 30}
            ),
            ['hello']
        )

    def test_words_dic_Cap(self):
        self.assertEqual(Generate_Words_Dic.gen_words_dic(
            {'HELLO': 30, 'BOY': 50}
        ),
            ['boy', 'hello']
        )

    def test_words_dic_5(self):
        self.assertEqual(Generate_Words_Dic.gen_words_dic(
            {'Nice': 20, 'OK': 1, 'MeEt': 10, 'hello': 30, 'tO': 15, 'you': 5, 'BoY': 25,}
        ),
            ['hello', 'boy', 'nice', 'to', 'meet']
        )

