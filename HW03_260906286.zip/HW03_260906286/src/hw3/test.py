import unittest
import sys
import os.path as osp
sys.path.append(osp.dirname(osp.dirname(osp.abspath(__file__))))
print(osp.dirname(osp.abspath(__file__)))
from hw3.tests.test_cases import *

if __name__ == '__main__':

    unittest.main()
