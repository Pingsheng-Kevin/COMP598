# This function checks if the length of a list is >= 5 or not,
# which determine how many elements to output in non-dictionary words.


class Check_L:

    def list_length(list):
        if 5 > len(list) >= 0:
            return False
        else:
            return True
