# This function accepts a unordered list of {caseless string: frequency} dicitionary pair
# and return an list of {caseless string: frequency} with length<=5
import re
import os.path as osp
from .generate_dic import Gen_Dic

class Generate_Words_Dic:
    def gen_words_dic(unorder_dic):

        unorder_dic_caseless_keys = {k.lower(): v for (k, v) in unorder_dic.items()}


        ordered_list_tuples = sorted(unorder_dic_caseless_keys.items(), key=lambda a: a[1], reverse=True)

        ordered_list_keys = []

        if len(ordered_list_tuples) >= 5:
            for i in range(0, 5):
                ordered_list_keys.append(ordered_list_tuples[i][0])
        elif 5 > len(ordered_list_tuples) > 0:
            for i in range(0, len(ordered_list_tuples)):
                ordered_list_keys.append(ordered_list_tuples[i][0])

        return ordered_list_keys
