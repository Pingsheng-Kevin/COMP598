# This function generates a set of dictionary words based on file words_alpha.txt in data
import warnings
class Gen_Dic:


    def gen_dic(dicpath):
        warnings.filterwarnings('ignore')
        dic = set(line.strip().casefold() for line in open(dicpath, 'r'))

        return dic
