import pandas as pds
import json
import os.path as osp
import os
import sys
import warnings
import argparse as ap
import re


def main():
    warnings.filterwarnings('ignore')
    p = ap.ArgumentParser(description='Analysis of MLP scripts')
    p.add_argument('file_path', type=str, help='the path of the file you want to process.')

    p.add_argument('-o <filename>', '--outputfile', type=str, help='redirect the output to a json file following.')
    args = p.parse_args()
    filepath = args.file_path
    # print(osp.dirname(filepath))
    sys.path.append(osp.join(osp.dirname(os.path.dirname(os.path.abspath(__file__))), 'src'))
    # print(osp.join(osp.dirname(osp.dirname(os.getcwd())), 'src'))
    from hw3.check_list_length import Check_L
    from hw3.generate_words_dic import Generate_Words_Dic
    from hw3.generate_dic import Gen_Dic
    dicpath = osp.join(osp.dirname(osp.dirname(osp.abspath(__file__))), 'data', 'words_alpha.txt')
    dic = Gen_Dic.gen_dic(dicpath)
    df = pds.read_csv(filepath)

    df['dialog'] = df['dialog'].str.replace('<U\+.*>', ' ', regex=True)
    dic = set(line.strip() for line in open(dicpath, 'r'))

    df_WantedRows = df[df['pony'].str.contains('^[Tt]wilight [Ss]parkle$', regex=True) |
                         df['pony'].str.contains('^([Aa]pplejack)$', regex=True) |
                         df['pony'].str.contains('^([Rr]ainbow) [Dd]ash$', regex=True) |
                         df['pony'].str.contains('^([Rr]arity)$', regex=True) |
                         df['pony'].str.contains('^([Pp]inkie [Pp]ie)$', regex=True) |
                         df['pony'].str.contains('^([Ff]luttershy)$', regex=True)
    ]
    # print(df_WantedRows.shape[0])
    df_desired = df[['title', 'pony']]

    dfg = df_desired.groupby(
        ((df_desired['pony'].shift() != df_desired['pony'])
          |
          (df_desired['title'].shift() != df_desired['title'])).cumsum()
    )
    count_TS = 0
    count_AJ = 0
    count_RD = 0
    count_R = 0
    count_PP = 0
    count_F = 0
    for k, v in dfg:
        # print(f'[group {k}]')
        # print(v)
        if v.iloc[0, 1].casefold() == 'twilight sparkle':
            count_TS += 1
        elif v.iloc[0, 1].casefold() == 'applejack':
            count_AJ += 1
        elif v.iloc[0, 1].casefold() == 'rainbow dash':
            count_RD += 1
        elif v.iloc[0, 1].casefold() == 'rarity':
            count_R += 1
        elif v.iloc[0, 1].casefold() == 'pinkie pie':
            count_PP += 1
        elif v.iloc[0, 1].casefold() == 'fluttershy':
            count_F += 1
    total = count_TS + count_AJ + count_F + count_PP + count_R + count_RD
    df_TS = df[df['pony'].str.contains('^([Tt]wilight [Ss]parkle)$', regex=True)]
    # print(df_TS.shape[0])
    df_AJ = df[df['pony'].str.contains('^([Aa]pplejack)$', regex=True)]
    # print(df_AJ.shape[0])
    df_RD = df[df['pony'].str.contains('^([Rr]ainbow [Dd]ash)$', regex=True)]
    # print(df_RD.shape[0])
    df_R = df[df['pony'].str.contains('^([Rr]arity)$', regex=True)]
    # print(df_R.shape[0])
    df_PP = df[df['pony'].str.contains('^([Pp]inkie [Pp]ie)$', regex=True)]
    # print(df_PP.shape[0])
    df_F = df[df['pony'].str.contains('^([Ff]luttershy)$', regex=True)]
    # print(df_F.shape[0])
    # print(total)
    data = {}
    values = {}
    data.update({'verbosity': values})
    values.update({
        'twilight': round(float(count_TS/total), 2),
        'pinkie': round(float(count_PP/total), 2),
        'fluttershy': round(float(count_F/total), 2),
        'rarity': round(float(count_R/total), 2),
        'applejack': round(float(count_AJ/total), 2),
        'rainbow': round(float(count_RD/total), 2)
    })


    values2 = {}
    data.update({'mentions': values2})

################################################################# Twilight Part below

    df_TS['mentions_pinkie'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Pinkie'
    ) + df_TS.dialog.str.count(
        r'Pinkie$'
    )
    df_TS['mentions_pie'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Pie'
    ) + df_TS.dialog.str.count(
        r'Pie$'
    )
    df_TS['mentions_pinkie_intersect'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^(Pinkie[^a-zA-Z0-9]Pie)'
    ) + df_TS.dialog.str.count(
        r'(Pinkie[^a-zA-Z0-9]Pie)$'
    )
    TS_mentions_PP = df_TS['mentions_pinkie'].sum()+df_TS['mentions_pie'].sum()-df_TS['mentions_pinkie_intersect'].sum()

    df_TS['mentions_fluttershy'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Fluttershy[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy$'
    )
    TS_mentions_F = df_TS['mentions_fluttershy'].sum()

    df_TS['mentions_rarity'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Rarity[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity$'
    )
    TS_mentions_R = df_TS['mentions_rarity'].sum()

    df_TS['mentions_applejack'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Applejack[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack$'
    )
    TS_mentions_AJ = df_TS['mentions_applejack'].sum()

    df_TS['mentions_rainbow'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Rainbow[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow$'
    )
    df_TS['mentions_dash'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^Dash[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Dash$'
    )
    df_TS['mentions_rainbow_intersect'] = df_TS.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'^(Rainbow[^a-zA-Z0-9]Dash)[^a-zA-Z0-9]'
    ) + df_TS.dialog.str.count(
        r'[^a-zA-Z0-9](Rainbow[^a-zA-Z0-9]Dash)$'
    )
    TS_mentions_RD = df_TS['mentions_rainbow'].sum() + df_TS['mentions_dash'].sum() - df_TS[
        'mentions_rainbow_intersect'].sum()
    TS_mentions_total = TS_mentions_AJ + TS_mentions_F + TS_mentions_PP + TS_mentions_R + TS_mentions_RD
    if TS_mentions_total == 0:
        value_TS_AJ = 0
        value_TS_F = 0
        value_TS_PP = 0
        value_TS_R = 0
        value_TS_RD = 0
    else:
        value_TS_AJ = round(float(TS_mentions_AJ/TS_mentions_total), 2)
        value_TS_F = round(float(TS_mentions_F/TS_mentions_total), 2)
        value_TS_PP = round(float(TS_mentions_PP/TS_mentions_total), 2)
        value_TS_R = round(float(TS_mentions_R/TS_mentions_total), 2)
        value_TS_RD = round(float(TS_mentions_RD/TS_mentions_total), 2)


################################################################# Pinkie Part Below

    df_PP['mentions_twilight'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^Twilight[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight$'
    )
    df_PP['mentions_sparkle'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^Sparkle[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle$'
    )
    df_PP['mentions_twilight_intersect'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^(Twilight[^a-zA-Z0-9]Sparkle)[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9](Twilight[^a-zA-Z0-9]Sparkle)$'
    )
    PP_mentions_TS = df_PP['mentions_twilight'].sum() + df_PP['mentions_sparkle'].sum() - df_PP[
        'mentions_twilight_intersect'].sum()

    df_PP['mentions_fluttershy'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^Fluttershy[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy$'
    )
    PP_mentions_F = df_PP['mentions_fluttershy'].sum()

    df_PP['mentions_rarity'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^Rarity[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity$'
    )
    PP_mentions_R = df_PP['mentions_rarity'].sum()

    df_PP['mentions_applejack'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack[^a-zA-Z0-9]'
    ) +  df_PP.dialog.str.count(
        r'^Applejack[^a-zA-Z0-9]'
    ) +  df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack$'
    )
    PP_mentions_AJ = df_PP['mentions_applejack'].sum()

    df_PP['mentions_rainbow'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^Rainbow[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow$'
    )
    df_PP['mentions_dash'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^Dash[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Dash$'
    )
    df_PP['mentions_rainbow_intersect'] = df_PP.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'^(Rainbow[^a-zA-Z0-9]Dash)[^a-zA-Z0-9]'
    ) + df_PP.dialog.str.count(
        r'[^a-zA-Z0-9](Rainbow[^a-zA-Z0-9]Dash)$'
    )
    PP_mentions_RD = df_PP['mentions_rainbow'].sum() + df_PP['mentions_dash'].sum() - df_PP[
        'mentions_rainbow_intersect'].sum()
    PP_mentions_total = PP_mentions_AJ + PP_mentions_F + PP_mentions_TS + PP_mentions_R + PP_mentions_RD
    if PP_mentions_total == 0:
        value_PP_AJ = 0
        value_PP_F = 0
        value_PP_TS = 0
        value_PP_R = 0
        value_PP_RD = 0
    else:
        value_PP_AJ = round(float(PP_mentions_AJ / PP_mentions_total), 2)
        value_PP_F = round(float(PP_mentions_F / PP_mentions_total), 2)
        value_PP_TS = round(float(PP_mentions_TS / PP_mentions_total), 2)
        value_PP_R = round(float(PP_mentions_R / PP_mentions_total), 2)
        value_PP_RD = round(float(PP_mentions_RD / PP_mentions_total), 2)

################################################################# Fluttershy Part Below

    df_F['mentions_twilight'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Twilight[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight$'
    )
    df_F['mentions_sparkle'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Sparkle[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle$'
    )
    df_F['mentions_twilight_intersect'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^(Twilight[^a-zA-Z0-9]Sparkle)[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9](Twilight[^a-zA-Z0-9]Sparkle)$'
    )
    F_mentions_TS = df_F['mentions_twilight'].sum() + df_F['mentions_sparkle'].sum() - df_F[
        'mentions_twilight_intersect'].sum()

    df_F['mentions_pinkie'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Pinkie[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie$'
    )
    df_F['mentions_pie'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Pie[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Pie$'
    )
    df_F['mentions_pinkie_intersect'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^(Pinkie[^a-zA-Z0-9]Pie)[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9](Pinkie[^a-zA-Z0-9]Pie)$'
    )
    F_mentions_PP = df_F['mentions_pinkie'].sum() + df_F['mentions_pie'].sum() - df_F[
        'mentions_pinkie_intersect'].sum()

    df_F['mentions_rarity'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Rarity[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity$'
    )
    F_mentions_R = df_F['mentions_rarity'].sum()

    df_F['mentions_applejack'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Applejack[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack$'
    )
    F_mentions_AJ = df_F['mentions_applejack'].sum()

    df_F['mentions_rainbow'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Rainbow[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow$'
    )
    df_F['mentions_dash'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^Dash[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Dash$'
    )
    df_F['mentions_rainbow_intersect'] = df_F.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'^(Rainbow[^a-zA-Z0-9]Dash)[^a-zA-Z0-9]'
    ) + df_F.dialog.str.count(
        r'[^a-zA-Z0-9](Rainbow[^a-zA-Z0-9]Dash)$'
    )
    F_mentions_RD = df_F['mentions_rainbow'].sum() + df_F['mentions_dash'].sum() - df_F[
        'mentions_rainbow_intersect'].sum()
    F_mentions_total = F_mentions_AJ + F_mentions_PP + F_mentions_TS + F_mentions_R + F_mentions_RD
    if F_mentions_total == 0:
        value_F_AJ = 0
        value_F_PP = 0
        value_F_TS = 0
        value_F_R = 0
        value_F_RD = 0
    else:
        value_F_AJ = round(float(F_mentions_AJ / F_mentions_total), 2)
        value_F_PP = round(float(F_mentions_PP / F_mentions_total), 2)
        value_F_TS = round(float(F_mentions_TS / F_mentions_total), 2)
        value_F_R = round(float(F_mentions_R / F_mentions_total), 2)
        value_F_RD = round(float(F_mentions_RD / F_mentions_total), 2)

    ################################################################# Rarity part below

    df_R['mentions_twilight'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Twilight[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight$'
    )
    df_R['mentions_sparkle'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Sparkle[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle$'
    )
    df_R['mentions_twilight_intersect'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^(Twilight[^a-zA-Z0-9]Sparkle)[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9](Twilight[^a-zA-Z0-9]Sparkle)$'
    )
    R_mentions_TS = df_R['mentions_twilight'].sum() + df_R['mentions_sparkle'].sum() - df_R[
        'mentions_twilight_intersect'].sum()

    df_R['mentions_pinkie'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Pinkie[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie$'
    )
    df_R['mentions_pie'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Pie[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Pie$'
    )
    df_R['mentions_pinkie_intersect'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^(Pinkie[^a-zA-Z0-9]Pie)[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9](Pinkie[^a-zA-Z0-9]Pie)$'
    )
    R_mentions_PP = df_R['mentions_pinkie'].sum() + df_R['mentions_pie'].sum() - df_R[
        'mentions_pinkie_intersect'].sum()

    df_R['mentions_fluttershy'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Fluttershy[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy$'
    )
    R_mentions_F = df_R['mentions_fluttershy'].sum()

    df_R['mentions_applejack'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Applejack[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack$'
    )
    R_mentions_AJ = df_R['mentions_applejack'].sum()

    df_R['mentions_rainbow'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Rainbow[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow$'
    )
    df_R['mentions_dash'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^Dash[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Dash$'
    )
    df_R['mentions_rainbow_intersect'] = df_R.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'^(Rainbow[^a-zA-Z0-9]Dash)[^a-zA-Z0-9]'
    ) + df_R.dialog.str.count(
        r'[^a-zA-Z0-9](Rainbow[^a-zA-Z0-9]Dash)$'
    )
    R_mentions_RD = df_R['mentions_rainbow'].sum() + df_R['mentions_dash'].sum() - df_R[
        'mentions_rainbow_intersect'].sum()
    R_mentions_total = R_mentions_AJ + R_mentions_PP + R_mentions_TS + R_mentions_F + R_mentions_RD
    if R_mentions_total == 0:
        value_R_AJ = 0
        value_R_PP = 0
        value_R_TS = 0
        value_R_F = 0
        value_R_RD = 0
    else:
        value_R_AJ = round(float(R_mentions_AJ / R_mentions_total), 2)
        value_R_PP = round(float(R_mentions_PP / R_mentions_total), 2)
        value_R_TS = round(float(R_mentions_TS / R_mentions_total), 2)
        value_R_F = round(float(R_mentions_F / R_mentions_total), 2)
        value_R_RD = round(float(R_mentions_RD / R_mentions_total), 2)

################################################################################  Applejack part below

    df_AJ['mentions_twilight'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Twilight[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight$'
    )
    df_AJ['mentions_sparkle'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Sparkle[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle$'
    )
    df_AJ['mentions_twilight_intersect'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^(Twilight[^a-zA-Z0-9]Sparkle)[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9](Twilight[^a-zA-Z0-9]Sparkle)$'
    )
    AJ_mentions_TS = df_AJ['mentions_twilight'].sum() + df_AJ['mentions_sparkle'].sum() - df_AJ[
        'mentions_twilight_intersect'].sum()

    df_AJ['mentions_pinkie'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Pinkie[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie$'
    )
    df_AJ['mentions_pie'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Pie[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Pie$'
    )
    df_AJ['mentions_pinkie_intersect'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^(Pinkie[^a-zA-Z0-9]Pie)[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9](Pinkie[^a-zA-Z0-9]Pie)$'
    )
    AJ_mentions_PP = df_AJ['mentions_pinkie'].sum() + df_AJ['mentions_pie'].sum() - df_AJ[
        'mentions_pinkie_intersect'].sum()

    df_AJ['mentions_fluttershy'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Fluttershy[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy$'
    )
    AJ_mentions_F = df_AJ['mentions_fluttershy'].sum()

    df_AJ['mentions_rarity'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Rarity[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity$'
    )
    AJ_mentions_R = df_AJ['mentions_rarity'].sum()

    df_AJ['mentions_rainbow'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Rainbow[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow$'
    )
    df_AJ['mentions_dash'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^Dash[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Dash$'
    )
    df_AJ['mentions_rainbow_intersect'] = df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9]Rainbow[^a-zA-Z0-9]Dash[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'^(Rainbow[^a-zA-Z0-9]Dash)[^a-zA-Z0-9]'
    ) + df_AJ.dialog.str.count(
        r'[^a-zA-Z0-9](Rainbow[^a-zA-Z0-9]Dash)$'
    )
    AJ_mentions_RD = df_AJ['mentions_rainbow'].sum() + df_AJ['mentions_dash'].sum() - df_AJ[
        'mentions_rainbow_intersect'].sum()
    AJ_mentions_total = AJ_mentions_R + AJ_mentions_PP + AJ_mentions_TS + AJ_mentions_F + AJ_mentions_RD
    if AJ_mentions_total == 0:
        value_AJ_R = 0
        value_AJ_PP = 0
        value_AJ_TS = 0
        value_AJ_F = 0
        value_AJ_RD = 0
    else:
        value_AJ_R = round(float(AJ_mentions_R / AJ_mentions_total), 2)
        value_AJ_PP = round(float(AJ_mentions_PP / AJ_mentions_total), 2)
        value_AJ_TS = round(float(AJ_mentions_TS / AJ_mentions_total), 2)
        value_AJ_F = round(float(AJ_mentions_F / AJ_mentions_total), 2)
        value_AJ_RD = round(float(AJ_mentions_RD / AJ_mentions_total), 2)

################################################################################ Rainbow Dash Part Below

    df_RD['mentions_twilight'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^Twilight[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight$'
    )
    df_RD['mentions_sparkle'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^Sparkle[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Sparkle$'
    )
    df_RD['mentions_twilight_intersect'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Twilight[^a-zA-Z0-9]Sparkle[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^(Twilight[^a-zA-Z0-9]Sparkle)[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9](Twilight[^a-zA-Z0-9]Sparkle)$'
    )
    RD_mentions_TS = df_RD['mentions_twilight'].sum() + df_RD['mentions_sparkle'].sum() - df_RD[
        'mentions_twilight_intersect'].sum()

    df_RD['mentions_pinkie'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^Pinkie[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie$'
    )
    df_RD['mentions_pie'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^Pie[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Pie$'
    )
    df_RD['mentions_pinkie_intersect'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Pinkie[^a-zA-Z0-9]Pie[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^(Pinkie[^a-zA-Z0-9]Pie)[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9](Pinkie[^a-zA-Z0-9]Pie)$'
    )
    RD_mentions_PP = df_RD['mentions_pinkie'].sum() + df_RD['mentions_pie'].sum() - df_RD[
        'mentions_pinkie_intersect'].sum()

    df_RD['mentions_fluttershy'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^Fluttershy[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Fluttershy$'
    )
    RD_mentions_F = df_RD['mentions_fluttershy'].sum()

    df_RD['mentions_rarity'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Rarity$'
    ) + df_RD.dialog.str.count(
        r'^Rarity[^a-zA-Z0-9]'
    )
    RD_mentions_R = df_RD['mentions_rarity'].sum()

    df_RD['mentions_applejack'] = df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'^Applejack[^a-zA-Z0-9]'
    ) + df_RD.dialog.str.count(
        r'[^a-zA-Z0-9]Applejack$'
    )

    RD_mentions_AJ = df_RD['mentions_applejack'].sum()

    RD_mentions_total = RD_mentions_R + RD_mentions_PP + RD_mentions_TS + RD_mentions_F + RD_mentions_AJ
    if RD_mentions_total == 0:
        value_RD_R = 0
        value_RD_PP = 0
        value_RD_TS = 0
        value_RD_F = 0
        value_RD_AJ = 0
    else:
        value_RD_R = round(float(RD_mentions_R / RD_mentions_total), 2)
        value_RD_PP = round(float(RD_mentions_PP / RD_mentions_total), 2)
        value_RD_TS = round(float(RD_mentions_TS / RD_mentions_total), 2)
        value_RD_F = round(float(RD_mentions_F / RD_mentions_total), 2)
        value_RD_AJ = round(float(RD_mentions_AJ / RD_mentions_total), 2)

    values2.update({
        'twilight': {'pinkie': value_TS_PP,
                     'fluttershy': value_TS_F,
                     'rarity': value_TS_R,
                     'applejack': value_TS_AJ,
                     'rainbow': value_TS_RD
                     },

        'pinkie': {'twilight': value_PP_TS,
                   'fluttershy': value_PP_F,
                   'rarity': value_PP_R,
                   'applejack': value_PP_AJ,
                   'rainbow': value_PP_RD
                   },

        'fluttershy': {'twilight': value_F_TS,
                       'pinkie': value_F_PP,
                       'rarity': value_F_R,
                       'applejack': value_F_AJ,
                       'rainbow': value_F_RD
                       },

        'rarity': {'twilight': value_R_TS,
                   'pinkie': value_R_PP,
                   'fluttershy': value_R_F,
                   'applejack': value_R_AJ,
                   'rainbow': value_R_RD
                   },

        'applejack': {'twilight': value_AJ_TS,
                      'pinkie': value_AJ_PP,
                      'fluttershy': value_AJ_F,
                      'rarity': value_AJ_R,
                      'rainbow': value_AJ_RD
                      },

        'rainbow': {'twilight': value_RD_TS,
                    'pinkie': value_RD_PP,
                    'fluttershy': value_RD_F,
                    'rarity': value_RD_R,
                    'applejack': value_RD_AJ
                    }
    })
# Set up for follow-on-comment
    values3 = {}

    follow_TS_PP = 0
    follow_TS_F = 0
    follow_TS_R = 0
    follow_TS_AJ = 0
    follow_TS_RD = 0
    follow_TS_O = 0

#   ##################################################### Twilight Sparkle Follow-on Part below
    for x in df_TS.index:
        if x == 0:
            continue
        else:
            if (df.iloc[x-1, 2] == 'Pinkie Pie' or df.iloc[x-1, 2] == 'pinkie pie') \
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_TS_PP += 1
                continue
            elif (df.iloc[x-1, 2] == 'Fluttershy' or df.iloc[x-1, 2] == 'fluttershy')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_TS_F += 1
                continue
            elif (df.iloc[x-1, 2] == 'Rarity' or df.iloc[x-1, 2] == 'rarity')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_TS_R += 1
                continue
            elif (df.iloc[x-1, 2] == 'Applejack' or df.iloc[x-1, 2] == 'applejack')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_TS_AJ += 1
                continue
            elif (df.iloc[x-1, 2] == 'Rainbow Dash' or df.iloc[x-1, 2] == 'rainbow dash')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_TS_RD += 1
                continue
            elif df.iloc[x-1, 0] == df.iloc[x, 0] and df.iloc[x - 1, 2] != 'Twilight Sparkle' \
                    and df.iloc[x - 1, 2] != 'twilight sparkle':
                follow_TS_O += 1

    total_TS = follow_TS_PP + follow_TS_F + follow_TS_R + follow_TS_AJ + follow_TS_RD + follow_TS_O

    if total_TS == 0:
        value_TS_PP = 0
        value_TS_F = 0
        value_TS_R = 0
        value_TS_AJ = 0
        value_TS_RD = 0
        value_TS_O = 0
    else:
        value_TS_PP = round(float(follow_TS_PP/total_TS), 2)
        value_TS_F = round(float(follow_TS_F/total_TS), 2)
        value_TS_R = round(float(follow_TS_R/total_TS), 2)
        value_TS_AJ = round(float(follow_TS_AJ/total_TS), 2)
        value_TS_RD = round(float(follow_TS_RD/total_TS), 2)
        value_TS_O = round(float(follow_TS_O/total_TS), 2)

#################################################### PP part below

    follow_PP_TS = 0
    follow_PP_F = 0
    follow_PP_R = 0
    follow_PP_AJ = 0
    follow_PP_RD = 0
    follow_PP_O = 0

    for x in df_PP.index:
        if x == 0:
            continue
        else:
            if (df.iloc[x-1, 2] == 'Twilight Sparkle' or df.iloc[x-1, 2] == 'twilight sparkle') \
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_PP_TS += 1
                continue
            elif (df.iloc[x-1, 2] == 'Fluttershy' or df.iloc[x-1, 2] == 'fluttershy')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_PP_F += 1
                continue
            elif (df.iloc[x-1, 2] == 'Rarity' or df.iloc[x-1, 2] == 'rarity')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_PP_R += 1
                continue
            elif (df.iloc[x-1, 2] == 'Applejack' or df.iloc[x-1, 2] == 'applejack')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_PP_AJ += 1
                continue
            elif (df.iloc[x-1, 2] == 'Rainbow Dash' or df.iloc[x-1, 2] == 'rainbow dash')\
                    and df.iloc[x-1, 0] == df.iloc[x, 0]:
                follow_PP_RD += 1
                continue
            elif df.iloc[x-1, 0] == df.iloc[x, 0] and df.iloc[x - 1, 2] != 'Pinkie Pie' \
                    and df.iloc[x - 1, 2] != 'pinkie pie':
                follow_PP_O += 1

    total_PP = follow_PP_TS + follow_PP_F + follow_PP_R + follow_PP_AJ + follow_PP_RD + follow_PP_O

    if total_PP == 0:
        value_PP_TS = 0
        value_PP_F = 0
        value_PP_R = 0
        value_PP_AJ = 0
        value_PP_RD = 0
        value_PP_O = 0
    else:
        value_PP_TS = round(float(follow_PP_TS/total_PP), 2)
        value_PP_F = round(float(follow_PP_F/total_PP), 2)
        value_PP_R = round(float(follow_PP_R/total_PP), 2)
        value_PP_AJ = round(float(follow_PP_AJ/total_PP), 2)
        value_PP_RD = round(float(follow_PP_RD/total_PP), 2)
        value_PP_O = round(float(follow_PP_O/total_PP), 2)
#################################################### Fluttershy Follow-on Part below
    follow_F_TS = 0
    follow_F_PP = 0
    follow_F_R = 0
    follow_F_AJ = 0
    follow_F_RD = 0
    follow_F_O = 0

    for x in df_F.index:
        if x == 0:
            continue
        else:
            if (df.iloc[x - 1, 2] == 'Twilight Sparkle' or df.iloc[x - 1, 2] == 'twilight sparkle') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_F_TS += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Pinkie Pie' or df.iloc[x - 1, 2] == 'pinkie pie') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_F_PP += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Rarity' or df.iloc[x - 1, 2] == 'rarity') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_F_R += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Applejack' or df.iloc[x - 1, 2] == 'applejack') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_F_AJ += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Rainbow Dash' or df.iloc[x - 1, 2] == 'rainbow dash') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_F_RD += 1
                continue
            elif df.iloc[x - 1, 0] == df.iloc[x, 0] and df.iloc[x - 1, 2] != 'Fluttershy'\
                    and df.iloc[x - 1, 2] != 'fluttershy':
                follow_F_O += 1

    total_F = follow_F_TS + follow_F_PP + follow_F_R + follow_F_AJ + follow_F_RD + follow_F_O

    if total_F == 0:
        value_F_TS = 0
        value_F_PP = 0
        value_F_R = 0
        value_F_AJ = 0
        value_F_RD = 0
        value_F_O = 0
    else:
        value_F_TS = round(float(follow_F_TS / total_F), 2)
        value_F_PP = round(float(follow_F_PP / total_F), 2)
        value_F_R = round(float(follow_F_R / total_F), 2)
        value_F_AJ = round(float(follow_F_AJ / total_F), 2)
        value_F_RD = round(float(follow_F_RD / total_F), 2)
        value_F_O = round(float(follow_F_O / total_F), 2)
##################################################### Rarity Follow part
    follow_R_TS = 0
    follow_R_PP = 0
    follow_R_F = 0
    follow_R_AJ = 0
    follow_R_RD = 0
    follow_R_O = 0

    for x in df_R.index:
        if x == 0:
            continue
        else:
            if (df.iloc[x - 1, 2] == 'Twilight Sparkle' or df.iloc[x - 1, 2] == 'twilight sparkle') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_R_TS += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Pinkie Pie' or df.iloc[x - 1, 2] == 'pinkie pie') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_R_PP += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Fluttershy' or df.iloc[x - 1, 2] == 'fluttershy') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_R_F += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Applejack' or df.iloc[x - 1, 2] == 'applejack') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_R_AJ += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Rainbow Dash' or df.iloc[x - 1, 2] == 'rainbow dash') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_R_RD += 1
                continue
            elif df.iloc[x - 1, 0] == df.iloc[x, 0] and df.iloc[x - 1, 2] != 'Rarity' \
                    and df.iloc[x - 1, 2] != 'rarity':
                follow_R_O += 1

    total_R = follow_R_TS + follow_R_PP + follow_R_F + follow_R_AJ + follow_R_RD + follow_R_O

    if total_R == 0:
        value_R_TS = 0
        value_R_PP = 0
        value_R_F = 0
        value_R_AJ = 0
        value_R_RD = 0
        value_R_O = 0
    else:
        value_R_TS = round(float(follow_R_TS / total_R), 2)
        value_R_PP = round(float(follow_R_PP / total_R), 2)
        value_R_F = round(float(follow_R_F / total_R), 2)
        value_R_AJ = round(float(follow_R_AJ / total_R), 2)
        value_R_RD = round(float(follow_R_RD / total_R), 2)
        value_R_O = round(float(follow_R_O / total_R), 2)
##################################################### Applejack follow-on part
    follow_AJ_TS = 0
    follow_AJ_PP = 0
    follow_AJ_F = 0
    follow_AJ_R = 0
    follow_AJ_RD = 0
    follow_AJ_O = 0

    for x in df_AJ.index:
        if x == 0:
            continue
        else:
            if (df.iloc[x - 1, 2] == 'Twilight Sparkle' or df.iloc[x - 1, 2] == 'twilight sparkle') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_AJ_TS += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Pinkie Pie' or df.iloc[x - 1, 2] == 'pinkie pie') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_AJ_PP += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Fluttershy' or df.iloc[x - 1, 2] == 'fluttershy') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_AJ_F += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Rarity' or df.iloc[x - 1, 2] == 'rarity') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_AJ_R += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Rainbow Dash' or df.iloc[x - 1, 2] == 'rainbow dash') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_AJ_RD += 1
                continue
            elif df.iloc[x - 1, 0] == df.iloc[x, 0] and df.iloc[x - 1, 2] != 'Applejack' \
                    and df.iloc[x - 1, 2] != 'applejack':
                follow_AJ_O += 1

    total_AJ = follow_AJ_TS + follow_AJ_PP + follow_AJ_F + follow_AJ_R + follow_AJ_RD + follow_AJ_O

    if total_AJ == 0:
        value_AJ_TS = 0
        value_AJ_PP = 0
        value_AJ_F = 0
        value_AJ_R = 0
        value_AJ_RD = 0
        value_AJ_O = 0
    else:
        value_AJ_TS = round(float(follow_AJ_TS / total_AJ), 2)
        value_AJ_PP = round(float(follow_AJ_PP / total_AJ), 2)
        value_AJ_F = round(float(follow_AJ_F / total_AJ), 2)
        value_AJ_R = round(float(follow_AJ_R / total_AJ), 2)
        value_AJ_RD = round(float(follow_AJ_RD / total_AJ), 2)
        value_AJ_O = round(float(follow_AJ_O / total_AJ), 2)
##################################################################### Rainbow Dash follow-on part
    follow_RD_TS = 0
    follow_RD_PP = 0
    follow_RD_F = 0
    follow_RD_R = 0
    follow_RD_AJ = 0
    follow_RD_O = 0

    for x in df_RD.index:
        if x == 0:
            continue
        else:
            if (df.iloc[x - 1, 2] == 'Twilight Sparkle' or df.iloc[x - 1, 2] == 'twilight sparkle') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_RD_TS += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Pinkie Pie' or df.iloc[x - 1, 2] == 'pinkie pie') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_RD_PP += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Fluttershy' or df.iloc[x - 1, 2] == 'fluttershy') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_RD_F += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Rarity' or df.iloc[x - 1, 2] == 'rarity') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_RD_R += 1
                continue
            elif (df.iloc[x - 1, 2] == 'Applejack' or df.iloc[x - 1, 2] == 'applejack') \
                    and df.iloc[x - 1, 0] == df.iloc[x, 0]:
                follow_RD_AJ += 1
                continue
            elif df.iloc[x - 1, 0] == df.iloc[x, 0] and df.iloc[x - 1, 2] != 'Rainbow Dash' \
                    and df.iloc[x - 1, 2] != 'rainbow dash':
                follow_RD_O += 1

    total_RD = follow_RD_TS + follow_RD_PP + follow_RD_F + follow_RD_R + follow_RD_AJ + follow_RD_O

    if total_RD == 0:
        value_RD_TS = 0
        value_RD_PP = 0
        value_RD_F = 0
        value_RD_R = 0
        value_RD_AJ = 0
        value_RD_O = 0
    else:
        value_RD_TS = round(float(follow_RD_TS / total_RD), 2)
        value_RD_PP = round(float(follow_RD_PP / total_RD), 2)
        value_RD_F = round(float(follow_RD_F / total_RD), 2)
        value_RD_R = round(float(follow_RD_R / total_RD), 2)
        value_RD_AJ = round(float(follow_RD_AJ / total_RD), 2)
        value_RD_O = round(float(follow_RD_O / total_RD), 2)
#####################################################################
    data.update({'follow_on_comments': values3})
    values3.update({
        'twilight': {
            'pinkie': value_TS_PP,
            'fluttershy': value_TS_F,
            'rarity': value_TS_R,
            'applejack': value_TS_AJ,
            'rainbow': value_TS_RD,
            'other': value_TS_O
        },
        'pinkie': {
            'twilight': value_PP_TS,
            'fluttershy': value_PP_F,
            'rarity': value_PP_R,
            'applejack': value_PP_AJ,
            'rainbow': value_PP_RD,
            'other': value_PP_O
        },
        'fluttershy': {
            'twilight': value_F_TS,
            'pinkie': value_F_PP,
            'rarity': value_F_R,
            'applejack': value_F_AJ,
            'rainbow': value_F_RD,
            'other': value_F_O
        },
        'rarity': {
            'twilight': value_R_TS,
            'pinkie': value_R_PP,
            'fluttershy': value_R_F,
            'applejack': value_R_AJ,
            'rainbow': value_R_RD,
            'other': value_R_O
        },
        'applejack': {
            'twilight': value_AJ_TS,
            'pinkie': value_AJ_PP,
            'fluttershy': value_AJ_F,
            'rarity': value_AJ_R,
            'rainbow': value_AJ_RD,
            'other': value_AJ_O
        },
        'rainbow': {
            'twilight': value_RD_TS,
            'pinkie': value_RD_PP,
            'fluttershy': value_RD_F,
            'rarity': value_RD_R,
            'applejack': value_RD_AJ,
            'other': value_RD_O
        }
    })
######################################################## non-dictionary words part--TS

    # Generate_Words_Dic.gen_words_dic(df_TS, df)
    non_dic_TS = {}
    non_dic_list_TS = []
    for x in df_TS.index:
        for word in filter(None, re.split(r'[^a-zA-Z0-9]', df.iloc[x, 3].__str__().casefold())):
            if (word not in dic) and (word not in non_dic_TS):
                non_dic_TS[word.casefold()] = 1
            elif (word not in dic) and (word in non_dic_TS):
                non_dic_TS.update({word: non_dic_TS.get(word)+1})
    non_dic_top5_TS = sorted(non_dic_TS.items(), key=lambda a: a[1], reverse=True)
    # print(non_dic_TS.items())
    if len(non_dic_TS) >= 5:
        for i in range(0, 5):
            # print(non_dic_top5_TS[i])
            non_dic_list_TS.append(non_dic_top5_TS[i][0])
    elif 5 > len(non_dic_TS) > 0:
        for i in range(0, len(non_dic_list_TS)):
            non_dic_list_TS.append(non_dic_top5_TS[i][0])

############################################################ non-dictionary words part--PP
    non_dic_PP = {}
    non_dic_list_PP = []
    for x in df_PP.index:
        for word in filter(None, re.split(r'[^a-zA-Z0-9]', df.iloc[x, 3].__str__().casefold())):
            if (word not in dic) and (word not in non_dic_PP):
                non_dic_PP[word.casefold()] = 1
            elif (word not in dic) and (word in non_dic_PP):
                non_dic_PP.update({word: non_dic_PP.get(word) + 1})
    non_dic_top5_PP = sorted(non_dic_PP.items(), key=lambda a: a[1], reverse=True)
    # print(non_dic_TS.items())
    if len(non_dic_PP) >= 5:
        for i in range(0, 5):
            # print(non_dic_top5_TS[i])
            non_dic_list_PP.append(non_dic_top5_PP[i][0])
    elif 5 > len(non_dic_PP) > 0:
        for i in range(0, len(non_dic_list_PP), 1):
            non_dic_list_PP.append(non_dic_top5_PP[i][0])
############################################################ non dic part for fluttershy
    non_dic_F = {}
    non_dic_list_F = []
    for x in df_F.index:
        for word in filter(None, re.split(r'[^a-zA-Z0-9]', df.iloc[x, 3].__str__().casefold())):
            if (word not in dic) and (word not in non_dic_F):
                non_dic_F[word.casefold()] = 1
            elif (word not in dic) and (word in non_dic_F):
                non_dic_F.update({word: non_dic_F.get(word) + 1})
    non_dic_top5_F = sorted(non_dic_F.items(), key=lambda a: a[1], reverse=True)
    # print(non_dic_TS.items())
    if len(non_dic_F) >= 5:
        for i in range(0, 5):
            # print(non_dic_top5_TS[i])
            non_dic_list_F.append(non_dic_top5_F[i][0])
    elif 5 > len(non_dic_F) > 0:
        for i in range(0, len(non_dic_list_F), 1):
            non_dic_list_F.append(non_dic_top5_F[i][0])
    ############################################################ non dic part for rarity
    non_dic_R = {}
    non_dic_list_R = []
    for x in df_R.index:
        for word in filter(None, re.split(r'[^a-zA-Z0-9]', df.iloc[x, 3].__str__().casefold())):
            if (word not in dic) and (word not in non_dic_R):
                non_dic_R[word.casefold()] = 1
            elif (word not in dic) and (word in non_dic_R):
                non_dic_R.update({word: non_dic_R.get(word) + 1})
    non_dic_top5_R = sorted(non_dic_R.items(), key=lambda a: a[1], reverse=True)
    # print(non_dic_TS.items())
    if len(non_dic_R) >= 5:
        for i in range(0, 5):
            # print(non_dic_top5_TS[i])
            non_dic_list_R.append(non_dic_top5_R[i][0])
    elif 5 > len(non_dic_R) > 0:
        for i in range(0, len(non_dic_list_R), 1):
            non_dic_list_R.append(non_dic_top5_R[i][0])
    ############################################################ non dic part for applejack
    non_dic_AJ = {}
    non_dic_list_AJ = []
    for x in df_AJ.index:
        for word in filter(None, re.split(r'[^a-zA-Z0-9]', df.iloc[x, 3].__str__().casefold())):
            if (word not in dic) and (word not in non_dic_AJ):
                non_dic_AJ[word.casefold()] = 1
            elif (word not in dic) and (word in non_dic_AJ):
                non_dic_AJ.update({word: non_dic_AJ.get(word) + 1})
    non_dic_list = Generate_Words_Dic.gen_words_dic(non_dic_AJ)
    non_dic_top5_AJ = sorted(non_dic_AJ.items(), key=lambda a: a[1], reverse=True)
    # print(non_dic_TS.items())
    if len(non_dic_AJ) >= 5:
        for i in range(0, 5):
            # print(non_dic_top5_TS[i])
            non_dic_list_AJ.append(non_dic_top5_AJ[i][0])
    elif 5 > len(non_dic_AJ) > 0:
        for i in range(0, len(non_dic_list_AJ), 1):
            non_dic_list_AJ.append(non_dic_top5_AJ[i][0])
    ############################################################ non dic part for rainbow dash
    non_dic_RD = {}
    non_dic_list_RD = []
    for x in df_RD.index:
        for word in filter(None, re.split(r'[^a-zA-Z0-9]', df.iloc[x, 3].__str__().casefold())):
            if (word not in dic) and (word not in non_dic_RD):
                non_dic_RD[word.casefold()] = 1
            elif (word not in dic) and (word in non_dic_RD):
                non_dic_RD.update({word: non_dic_RD.get(word) + 1})
    non_dic_top5_RD = sorted(non_dic_RD.items(), key=lambda a: a[1], reverse=True)
    # print(non_dic_TS.items())
    b = [1]
    Check_L.list_length(b)
    if len(non_dic_RD) >= 5:
        for i in range(0, 5):
            # print(non_dic_top5_TS[i])
            non_dic_list_RD.append(non_dic_top5_RD[i][0])
    elif 5 > len(non_dic_RD) > 0:
        for i in range(0, len(non_dic_list_RD), 1):
            non_dic_list_RD.append(non_dic_top5_RD[i][0])
    ############################################################

    values4 = {}
    data.update({'non_dictionary_words': values4})

    values4.update({
        'twilight': non_dic_list_TS,
        'pinkie': non_dic_list_PP,
        'fluttershy': non_dic_list_F,
        'rarity': non_dic_list_R,
        'applejack': non_dic_list_AJ,
        'rainbow': non_dic_list_RD
    })
    if args.outputfile is None:
        print(json.dumps(data, indent=4, separators=(',', ': ')))
    else:
        with open(args.outputfile, 'w') as outfile:
            outfile.write(json.dumps(data, indent=4, separators=(',', ': ')))
            # something = pds.DataFrame(df_WantedRows)
            # outfile.write(something.to_csv(sep='\t'))


if __name__ == '__main__':

    main()

