import argparse
import json
import random
import os.path as osp


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-o', '--out_file', help='The output file of this script.')
    parser.add_argument('json_file')
    parser.add_argument('num_posts_to_output')

    args = parser.parse_args()
    num_posts_to_output = int(args.num_posts_to_output)
    json_file = args.json_file
    out_file = args.out_file
    if not osp.isabs(out_file):
        out_file = osp.abspath(out_file)
    to_stdout = False
    if args.out_file is None:
        to_stdout = True

    num_lines = sum(1 for line in open(json_file, 'r'))
    # print(num_lines)

    line_num_list = []
    if num_posts_to_output >= num_lines:
        line_num_list = [i for i in range(1, num_lines+1)]
        # print('Output all lines in json file')
    elif num_posts_to_output <= 0:
        print('Error! The number of posts to output file should be a positive integer!')
        exit(0)
    else:
        line_num_list = random.sample(range(1, num_lines+1), num_posts_to_output)
        line_num_list.sort()
        # print('Lines selected in json file: ' + str(line_num_list))

    line_num_pointer = 1
    posts_list = []
    while line_num_pointer <= num_lines:
        for line in open(json_file, 'r'):
            if line_num_list.__contains__(line_num_pointer):
                # print(json.loads(line)['data']['name'])
                json_object = json.loads(line)
                posts_list.append({'Name': json_object['data']['name'], 'title': json_object['data']['title']})
            line_num_pointer += 1

    if not to_stdout:
        with open(out_file, 'w') as out_file:
            header = 'Name\ttitle\tcoding\n'
            out_file.write(header)
            for post in posts_list:
                if post != posts_list[-1]:
                    this_line = post['Name'] + '\t' + post['title'] + '\t' + '\n'
                else:
                    this_line = post['Name'] + '\t' + post['title'] + '\t'
                out_file.write(this_line)
    else:
        header = 'Name\ttitle\tcoding'
        print(header)
        for post in posts_list:
            this_line = post['Name'] + '\t' + post['title'] + '\t'
            print(this_line)


if __name__ == '__main__':
    main()
