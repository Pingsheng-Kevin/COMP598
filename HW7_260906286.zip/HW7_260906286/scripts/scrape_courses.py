import argparse
from bs4 import BeautifulSoup
import os
import os.path as osp
import hashlib
import requests


def extract_courses_from_contents(contents):
    courses_list = []
    soup = BeautifulSoup(contents, 'html.parser')
    head_div = soup.find('div', attrs={"class": "view-content"})
    # print(head_div)
    pointer = head_div
    pointer = pointer.find('div')
    while (pointer is not None) and (pointer.name == 'div'):
        current = pointer

        field = current.find('a').getText().strip()
        # print(re.match("[\)]$", field))

        segment = field.split(' ')
        if len(segment) <= 4:
            # print('Course format incorrect: too few words. Ignored.')
            pointer = pointer.next_sibling.next_sibling
            continue
        course_ID = segment[0] + ' ' + segment[1]
        # print(course_ID)
        credits = segment[-2] + ' ' + segment[-1]
        if not (credits.startswith('(') and credits.endswith(')')):
            # print('Course format incorrect: invalid field for credits number, no (). Ignored')
            pointer = pointer.next_sibling.next_sibling
            continue
        else:
            credits = credits.strip('(').strip(')')
            if credits.split()[1] != 'credits' and credits.split()[1] != 'credit':
                pointer = pointer.next_sibling.next_sibling
                continue
            credits = credits.split()[0]
            # print(credits)
        course_name = ' '.join(segment[2:-2])
        # print(course_name)

        courses_list.append(course_ID + ',' + course_name + ',' + credits)

        pointer = pointer.next_sibling.next_sibling

    return courses_list


def cache_webpage(url, cache_path):
    contents = requests.get(url).text
    file_name = hashlib.sha1(url.encode('utf-8')).hexdigest()
    full_file_name = file_name + '.html'
    with open(osp.join(cache_path, full_file_name), 'w') as f:
        f.write(contents)

    return osp.join(cache_path, full_file_name)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--cache_dir', help="the path of cache directory.")
    parser.add_argument('page_number', help='The index of page you want to scrape.')

    args = parser.parse_args()
    cache = args.cache_dir
    page_index = args.page_number
    if int(page_index) > 543 or int(page_index) < 0:
        print('page index out of bound! Should be between 0-543')
        exit(0)
    if cache is not None:
        use_cache = True
        if not osp.exists(cache):
            if not osp.isabs(cache):
                cache = osp.abspath(cache)
            os.makedirs(cache)
    else:
        use_cache = False

    # print(use_cache)

    link_base = 'https://www.mcgill.ca/study/2020-2021/courses/search?page='
    url = link_base + page_index
    if use_cache:
        cache_file = cache_webpage(url, cache)
        with open(cache_file, 'r') as cache:
            contents = cache.read()
    else:
        contents = requests.get(url).text
    # print(contents)
    courses_list = extract_courses_from_contents(contents)
    print('CourseID,Course Name,# of credits')
    for course in courses_list:
        print(course)


if __name__ == '__main__':
    main()
