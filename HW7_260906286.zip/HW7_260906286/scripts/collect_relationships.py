import argparse
from bs4 import BeautifulSoup
import json
import os
import os.path as osp
import hashlib
import requests


def extract_relationships_from_contents(target_contents_file, target):
    relationships = []
    with open(target_contents_file, 'r') as contents_file:
        soup = BeautifulSoup(contents_file, 'html.parser')
        current_dating = soup.find('h4', attrs={'class': 'ff-auto-status'})
        if current_dating.next_sibling.name == 'div':
            current_dating = current_dating.next_sibling
            desired_block = current_dating.find('a')
            # print(desired_block)
            couple = []
            couple.append(desired_block.getText().strip())
            couple.append(desired_block.next_sibling.next_sibling.getText().strip())
            for person in couple:
                if person.lower().replace(' ', '-') == target:
                    couple.remove(person)
                    continue
                relationships.append(person)

        dating_history = soup.find('h4', attrs={'class': 'ff-auto-relationships'})
        head = dating_history.next_sibling
        # print(head)
        """
        if dating_history is None:
            # print(relationships)
            return relationships
        # print(dating_history_table)
        """
        pointer = head
        if head.find('a') is None:
            return relationships
        while (pointer is not None) and (pointer.name == 'p'):
            inner_pointer = pointer.find('a')
            # print(inner_pointer)
            while (inner_pointer is not None) and (inner_pointer.name == 'a'):
                text = inner_pointer.getText().strip()
                relationships.append(text)
                if inner_pointer.next_sibling.name == 'span':
                    inner_pointer = inner_pointer.next_sibling.next_sibling.next_sibling
                else:
                    inner_pointer = inner_pointer.next_sibling.next_sibling
            # print(len(current))
            pointer = pointer.next_sibling

        contents_file.close()
        # print(relationships)
    return relationships




def get_url_target_content(target, use_cache, cache_path):
    # download and cache
    if (not osp.exists(cache_path)) and use_cache:
        # print('creating cache dir...')
        os.makedirs(cache_path)
        # print('cache created!')
    elif osp.exists(cache_path) and (not osp.isdir(cache_path)) and use_cache:
        os.makedirs(cache_path)
        # print('cache_path is null or empty string or cache has already exist!')

    # print("The target: " + target)
    link_base = 'https://www.whosdatedwho.com/dating/'

    target_url = link_base + target
    # print("URL: " + target_url)

    file_name = hashlib.sha1(target_url.encode('utf-8')).hexdigest()
    if osp.isabs(cache_path) and use_cache:
        full_file_name = osp.join(cache_path, file_name + '.html')
    elif use_cache:
        full_file_name = osp.join(osp.abspath(cache_path), file_name + '.html')
    else:
        full_file_name = "temp.html"

    if osp.exists(full_file_name) and use_cache:
        print('Loading from cache...')
    else:
        print('Loading from the source...')

        contents = requests.get(target_url).text
        test_soup = BeautifulSoup(contents, 'html.parser')
        c = test_soup.find('div', attrs={"class": "ff-cont-wrapper", "data-ff-id": "ff-main-content-area"})
        if c is not None:
            # print(c.getText())
            raise ValueError
        """
        f = open('tf.html', 'w')
        f.write(contents)
        f.close()
        f = open('tf.html', 'r')
        test_soup = BeautifulSoup(f, 'html.parser')
        check = test_soup.find('div', attrs={"class": "ff-cont-wrapper", "data-ff-id": "ff-main-content-area"})\
            .getText()
        print(check.find("h1").getText().strip())
        if check.find("h1").getText().strip() == 'Page not found':
            raise AttributeError
        """
        with open(full_file_name, 'w') as fh:
            fh.write(contents)
            fh.close()
        # os.remove(osp.abspath(f))
    # print('printing contents from target_url...')
    # print(contents)
    return full_file_name


def open_config(file_path):
    with open(file_path, 'r') as file:
        read = json.load(file)
        # print(read)
        file.close()
        return read


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--config_file', help="The configuration file path")
    parser.add_argument('-o', '--output_file', help='The output file path')

    args = parser.parse_args()
    config_file = args.config_file
    # print('loading json...')
    config = open_config(config_file)
    # print('loading completed...')

    # print("")
    if 'cache_dir' in config.keys():
        cache_path = config['cache_dir']
    else:
        cache_path = None
        # print("cache_dir not provided!")
    # print(f"The cache path is: {cache_path}")
    if (not ('target_people' in config.keys())) or (config['target_people'] is None) or \
            (len(config['target_people']) == 0):
        print('Error: No target_people provided')
        exit(0)
    if (cache_path is not None) and (cache_path != ""):
        use_cache = True
    else:
        cache_path = ""
        use_cache = False
    summary = {}
    for target in config['target_people']:
        relationships = []
        try:
            target_html = get_url_target_content(target, use_cache, cache_path)
        except ValueError:
            print(f"Page not found for the target: {target}. It has been ignored.")
            continue
        for person in extract_relationships_from_contents(target_html, target):
            relationships.append(person)
        summary.update({target: relationships})
    # print(json.dumps(summary, indent=4))
    with open(args.output_file, 'w') as output:
        output.write(json.dumps(summary, indent=4))
        output.close()
    if not use_cache:
        os.remove(target_html)
    # print(summary)


if __name__ == '__main__':
    main()
