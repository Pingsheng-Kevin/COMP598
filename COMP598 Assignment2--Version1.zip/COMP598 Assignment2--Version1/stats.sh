wc -l $1 | awk '{print $1}'
head -n 1 $1
tail -n 10000 $1 | grep -i "potus" | wc -l | awk '{print $1}'
sed '100,200!d' $1 | grep "fake" | wc -l | awk '{print $1}'

