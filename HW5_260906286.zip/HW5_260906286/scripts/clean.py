import json
import argparse
from datetime import datetime


def clean_invalid_datetime(input_json_list):
    clean_data = []
    for json_object in input_json_list:
        if 'createdAt' in json_object.keys():
            # check data type
            if type(json_object.get('createdAt')) is not str:
                continue
            time_str = json_object.get('createdAt')
            if len(time_str) < 4:
                continue
            if ':' == time_str[-3]:
                time_str = time_str[:-3] + time_str[-2:]
            try:
                utc_time_with_offset = datetime.strptime(time_str, "%Y-%m-%dT%H:%M:%S%z")
                utc = datetime.strptime('+0000', "%z")
                utc_time_zone = utc_time_with_offset - utc_time_with_offset.utcoffset()

                json_object['createdAt'] = str(utc_time_zone.replace(tzinfo=utc.tzinfo).strftime("%Y-%m-%dT%H:%M:%S%z"))
                # print(json_object['createdAt'])
                clean_data.append(json_object)
            except ValueError:
                continue
        else:
            clean_data.append(json_object)
            continue
    # return a list of standardized time clean json objects
    return clean_data


def clean_invalid_title(input_json_list):
    # assert input_json_list.type is list of json objects
    clean_data = []
    for json_object in input_json_list:
        if 'title' in json_object.keys():
            clean_data.append(json_object)
        elif 'title_text' in json_object.keys():
            json_object['title'] = json_object.pop('title_text')
            clean_data.append(json_object)
        else:
            continue
    return clean_data


def main():
    parser = argparse.ArgumentParser(description='Clean the input JSON file and output it')
    parser.add_argument('-i <input_file_path>', '--input_file', type=str,
                        help='the path of JSON file you want to clean.')
    parser.add_argument('-o <output_file_path>', '--output_file', type=str,
                        help='where the cleaned JSON file you want to output to.')
    args = parser.parse_args()
    if (args.input_file is None) or (args.output_file is None):
        print('Arguments missing. Please ensure you provide input and output file.')
    data = []
    try:
        with open(args.input_file, 'r') as input:

            for line in input:
                """if line is None:
                    continue
                """
                # print(line)
                # filter the invalid json objects
                try:
                    data.append(json.loads(line))
                except json.decoder.JSONDecodeError:
                    continue
    except FileNotFoundError:
        print('No such file! Please check your input_file argument!')
        exit(0)
    # clean or transform invalid json objects that have invalid title field
    data = clean_invalid_title(data)

    # clean invalid json with invalid time and standardize the time
    data = clean_invalid_datetime(data)

    with open(args.output_file, 'w') as output:
        for json_object in data:
            if json_object is data[-1]:
                # print(json_object)
                output.write(json.dumps(json_object))
            else:
                # print(json_object)
                output.write(json.dumps(json_object)+'\n')


    """
    i = 1
    for element in data:
        print(f'{i}' + ': ' + str(element))
        i = i + 1
    """


if __name__ == '__main__':
    main()
