import json
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('input_file', help='the json file you want to read')
    args = parser.parse_args()

    if args.input_file is None:
        print('Input file is missing.')
        return
    titles = []
    with open(args.input_file, 'r') as input:
        for line in input:
            if line is None:
                continue
            else:
                try:
                    titles.append(json.loads(line)['data']['title'])
                except json.JSONDecodeError:
                    continue
    char_count = 0
    for title in titles:
        char_count = char_count + len(title)
    mean_length = (char_count*1.0)/(1.0*len(titles))
    print(round(mean_length, 2))
    # print(len(" "))
    """
    print(titles)
    print(len(titles))
    """


if __name__ == '__main__':
    main()
